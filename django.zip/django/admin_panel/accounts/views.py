from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth

# Create your views here.
def index(request):
    return render(request,'normal/index.html')


def signupPage(request):
    return render(request,'normal/signup.html')


def signinPage(request):
    return render(request,'normal/signin.html')


def signUp(request):
    if request.method == "POST":
        fname = request.POST['first_name']
        lname = request.POST['last_name']
        email = request.POST['email']
        unm = request.POST['username'] #ABC123
        pwd = request.POST['password']
        try :
                user = User.objects.get(username=unm)
                return render(request,'normal/signup.html',{'error':"Username Already Exists...!!!"})
        except :
            user = User.objects.create_user(first_name=fname,last_name=lname,email=email,username=unm,password=pwd)   
            user.save()
            return render(request,'normal/signup.html',{'msg':"Registered Successfully...!!!"})
    else:
        return render(request,'normal/signup.html',{'error':"Invalid User Request...!!!"})



def signIn(request):
    if request.method == "POST":
        unm = request.POST['username']
        pwd = request.POST['password']
        user = auth.authenticate(username=unm,password=pwd)
        if user is not None:
            auth.login(request,user)
            return redirect('userhome')
        else:
            return render(request,'normal/signin.html',{'error' : "Invalid Username or Password...!!!"})
    
    else:
        return render(request,'normal/signin.html',{'error' : "Invalid User Request...!!!"})


def userHome(request):
    return render(request,'private/userhome.html')


def signOut(request):
    auth.logout(request)
    return render(request,'normal/signin.html',{'msg':"Logged Out Successfully....!!!"})