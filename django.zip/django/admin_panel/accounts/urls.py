from django.urls import path
from . import views

urlpatterns = [
      path("",views.index),
      path('signuppage',views.signupPage,name='signuppage'),
      path('signinpage',views.signinPage,name='signinpage'),
      path('signup',views.signUp,name='signup'),
      path('userhome',views.userHome,name='userhome'),
      path('signin',views.signIn,name='signin'),
      path('signout',views.signOut,name='signout'),
]
