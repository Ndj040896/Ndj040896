from django.shortcuts import render,redirect
from .forms import EmpForm
from .models import Employe
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def addEmpPage(request):
    empForm = EmpForm()
    return render(request,'private/addemp.html',{'empForm':empForm})

@login_required
def insertEmp(request):
    if request.method == "POST":
        empForm = EmpForm(request.POST)
        if empForm.is_valid():
            empForm.save()
            #return render(request,'private/addemp.html',{'empForm':EmpForm(),'msg':"Employee Added..!!"})
            return redirect('getEmpDetails')
        else:
            return redirect('addemp')
    else:
        return redirect('addemp')

@login_required
def getEmpDetails(request):
    employees = Employe.objects.all()
    return render(request,'private/empdetails.html',{'employees':employees})

@login_required
def editEmp(request,eid):
    emp = Employe.objects.get(eid=eid)
    return render(request,'private/edit.html',{'emp':emp})

@login_required
def updateEmp(rquest,eid):
    if rquest.method == "POST":
        emp = Employe.objects.get(eid=eid)
        form = EmpForm(rquest.POST,instance=emp)
        if form.is_valid():
            form.save()
            return redirect('getEmpDetails')
        else:
            return render(request,'private/edit.html',{'emp':emp,'msg':'Details Not Updated...!!!'})
    else:
            return render(request,'private/edit.html',{'emp':emp,'msg':'Details Not Updated...!!!'})

@login_required
def deleteEmp(request,eid):
    emp = Employe.objects.get(eid=eid)
    emp.delete()
    return redirect('getEmpDetails')

    
def view_404(request,exception):
    return render(request,'normal/error.html')
