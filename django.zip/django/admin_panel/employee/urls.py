from django.urls import path
from . import views

urlpatterns = [
    path('addemp',views.addEmpPage,name='addemp'),
    path('insertemp',views.insertEmp,name='insertemp'),
    path('getEmpDetails',views.getEmpDetails,name='getEmpDetails'),
    path('editEmp/<int:eid>',views.editEmp,name="editEmp"),
    path('updateEmp/<int:eid>',views.updateEmp,name="updateEmp"),
    path('deleteEmp/<int:eid>',views.deleteEmp,name="deleteEmp"),

]
