from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    print("Home Request Get Successfully...!!!")
    #return HttpResponse("<h1>This Home Page of Django Application.</h1><br><h2>Server loaded Successfully.</h2>")
    return render(request,'home.html')

def abc(request):
    print("ABC Request Get Successfully....!!!")
    return HttpResponse("<h1>XYZ Request Get Successfully...!!!</h1>")

def index(request):
    #return HttpResponse("<h1>Index Request Get Successfully...!!!</h1>");
    return render(request,'index.html')