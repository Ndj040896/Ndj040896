from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request,'home.html')


def wordCount(request):
    data = request.GET['data']
    print("Data Insert By User : ",data)
    words = data.split()
    print(words)
    dict = {}
    for i in words:
        if i in dict:
            dict[i] +=1
        else:
            dict[i]=1

    print(dict)
    return render(request,'result.html',{'data':data,'total':len(words),'counts':dict})

